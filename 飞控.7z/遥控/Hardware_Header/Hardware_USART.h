#ifndef __Hardware_USART_H
#define __Hardware_USART_H

#include <stdio.h>
#include "stdint.h"

extern uint8_t Hardware_USART_TxPacket[];
extern uint8_t Hardware_USART_RxPacket[];

void Hardware_USART_Init(void);
void Hardware_USART_SendByte(uint8_t Byte);
void Hardware_USART_SendArray(uint8_t *Array, uint16_t Length);
void Hardware_USART_SendString(char *String);
void Hardware_USART_SendNumber(uint32_t Number, uint8_t Length);
void Hardware_USART_Printf(char *format, ...);

void Hardware_USART_SendPacket(void);
uint8_t Hardware_USART_GetRxFlag(void);

#endif
