#include "stdint.h"
#ifndef __BMP280_H
#define __BMP280_H

extern double Current_Height;

void BMP280_Init(void);
double BMP280_Get_Pressure(void);
double BMP280_Get_Temperature(void);
double BMP280_Get_Height(void);
uint8_t BMP280_ReadID(void);
void BMP280Data_Packet(double x);

#endif
