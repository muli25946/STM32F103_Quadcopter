#include "stdint.h"
#ifndef __Hareware_SPI_H
#define __Hardware_SPI_H

void Hardware_SPI_W_CSN(uint8_t BitValue);
void Hardware_SPI_Init(void);
void Hardware_SPI_Start(void);
void Hardware_SPI_Stop(void);
uint8_t Hardware_SPI_SwapByte(uint8_t ByteSend);

#endif
