#include "stdint.h"

#ifndef __PWM_H
#define __PWM_H

void PWM_Init(uint16_t ARR,uint16_t PSC);
void PWM_SetCompare1(uint16_t Compare);
void PWM_SetCompare2(uint16_t Compare);
void PWM_SetCompare3(uint16_t Compare);
void PWM_SetCompare4(uint16_t Compare);
void PWM_SetPrescaler(uint16_t Prescaler);

#endif
