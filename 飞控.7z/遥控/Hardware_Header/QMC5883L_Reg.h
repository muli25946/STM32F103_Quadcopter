#ifndef QMC5883L_Reg_H
#define QMC5883L_Reg_H

#define QMC5883L_X_LSB      0x00
#define QMC5883L_X_MSB      0x01
#define QMC5883L_Y_LSB      0x02
#define QMC5883L_Y_MSB      0x03
#define QMC5883L_Z_LSB      0x04
#define QMC5883L_Z_MSB      0x05

#define QMC5883L_Control    0x09
#define QMC5883L_ID         0x0D

#endif
