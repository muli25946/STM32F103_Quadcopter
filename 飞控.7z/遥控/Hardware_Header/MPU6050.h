#include "stdint.h"
#ifndef __MPU6050_
#define __MPU6050_

extern float pitch_raw;		        // 俯仰角pitch原始数据
extern float roll_raw;			    // 横滚角roll原始数据

extern float pitch_rate;//pitch角速率
extern float roll_rate;//roll角速率

void MPU6050_Init(void);
uint8_t MPU6050_GetID(void);
void MPU6050_GetAccel(int16_t *Acc_X,int16_t *Acc_Y,int16_t *Acc_Z);
void MPU6050_GetGyro(int16_t *Gyro_X,int16_t *Gyro_Y,int16_t *Gyro_Z);
void MPU6050_Cal(void);
void pitch_roll_RateCal(void);

#endif
