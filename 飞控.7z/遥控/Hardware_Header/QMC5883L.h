#include "stdint.h"
#ifndef QMC5883L_H
#define QMC5883L_H

void QMC5883L_Init(void);
void QMC5883L_Get_MagData(int16_t *Mag_X, int16_t *Mag_Y, int16_t *Mag_Z);

#endif
