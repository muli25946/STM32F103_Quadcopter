#ifndef __KALMAN_CAL_H
#define __KALMAN_CAL_H

extern float roll, pitch, yaw; // 滤波后的roll,pitch，yaw轴数据(yaw轴数据有毛病)

void kalman_filter_attitude_solution_calibyaw(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz);
void KalmanData_Packet(float x,float y);

#endif
