#include "stm32f10x.h"
#include "PWM.h"
#include "IC.h"

void PWM_SIMULATE_GAS_Init(void)
{
    PWM_Init(1000,1440);
    IC_Init();

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    PWM_SetPrescaler(14400-1); // 得到50Hz频率,周期2ms
}

/**
 * @brief 模拟油门设置为最小
 * @param 无
 * @retval 无
 */
void PWM_SIMULATE_GAS_Min(void)
{
    PWM_SetCompare1(50); // 1ms,对应电调最小量程
}

/**
 * @brief 模拟油门设置为最大
 * @param 无
 * @retval 无
 */
void PWM_SIMULATE_GAS_Max(void)
{
    PWM_SetCompare1(100); // 2ms,对应电调最大量程
}

/**
 * @brief 模拟油门设置为最一半
 * @param 无
 * @retval 无
 */
void PWM_SIMULATE_GAS_Mid(void)
{
    PWM_SetCompare1(75); // 2ms,对应电调最大量程
}
