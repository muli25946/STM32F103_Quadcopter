#include "stm32f10x.h"

/*宏定义，便于更改引脚*/
#define SCL GPIO_Pin_10 
#define SDA GPIO_Pin_11 

/*I2C常用操作函数封装*/
/*I2C写SCL电平*/
void Software_I2C_W_SCL(uint8_t BitVal)
{
    GPIO_WriteBit(GPIOB,SCL,(BitAction)BitVal);
}

/*I2C写SCL引脚电平*/
void Software_I2C_W_SDA(uint8_t BitVal)
{
    GPIO_WriteBit(GPIOB,SDA,(BitAction)BitVal);
}

/*I2C读SDA引脚电平*/
uint8_t Software_I2C_R_SDA()
{
    uint8_t BitVal;
    BitVal = GPIO_ReadInputDataBit(GPIOB,SDA);
    return BitVal;
}

/*引脚初始化*/
void Software_I2C_Init()
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStruct.GPIO_Pin = SCL | SDA;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    /*设置默认电平*/
    GPIO_SetBits(GPIOB, SCL | SDA);
}

/*I2C开启*/
void Software_I2C_Start()
{
    Software_I2C_W_SCL(1);
    Software_I2C_W_SDA(1);
    Software_I2C_W_SDA(0);
    Software_I2C_W_SCL(0);
}

/*I2C停止*/
void Software_I2C_Stop()
{
    //Software_I2C_W_SCL(0);  //每次通信默认拉低，不用再次拉低
    Software_I2C_W_SDA(0);
    Software_I2C_W_SCL(1);
    Software_I2C_W_SDA(1);
}

/*I2C发送一个字节*/
void Software_I2C_SendByte(uint8_t Byte)
{   uint8_t i;
    for(i=0;i<8;i++)
    {
        Software_I2C_W_SDA(Byte & (0x80 >> i));
        Software_I2C_W_SCL(1);
        Software_I2C_W_SCL(0);
    }
}

/*I2C接收一个字节*/
uint8_t Software_I2C_ReceiveByte()
{
    uint8_t i,Byte=0x00;
    Software_I2C_W_SDA(1);
    for(i=0;i<8;i++)
    {
        Software_I2C_W_SCL(1);
        if(Software_I2C_R_SDA()==1)
        {
            Byte |=(0x80 >>i);
        }
        Software_I2C_W_SCL(0);
    }
    return Byte;
}

/*I2C发送应答位*/
void Software_I2C_SendAck(uint8_t AckBit)
{
    Software_I2C_W_SDA(AckBit);
    Software_I2C_W_SCL(1);
    Software_I2C_W_SCL(0);
}

/*I2C接收应答*/
uint8_t Software_I2C_receiveAck()
{   
    uint8_t AckBit;
    Software_I2C_W_SDA(1);
    Software_I2C_W_SCL(1);
    AckBit =Software_I2C_R_SDA();
    Software_I2C_W_SCL(0);
    return AckBit;
}
