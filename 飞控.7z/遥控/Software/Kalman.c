#include "stm32f10x.h"
#include <math.h>
#include <float.h>

// extern uint8_t TransmitData_Buff[];

float roll = 0, pitch = 0, yaw = 0; // 欧拉角
static float Xk_[3] = {0};			// 先验估计
static float Xk[3] = {0};			// 后验估计
static float Uk[3] = {0};			// 系统输入
static float Zk[3] = {0};			// 测量状态
static float Pk_[3] = {0};			// 先验估计误差的协方差
static float Pk[3] = {1, 1, 1};		// 后验估计误差的协方差
static float K[3] = {0};			// 卡尔曼增益
static float Q[3] = {1, 1, 1};		// 系统噪声协方差
static float R[3] = {1, 1, 1};		// 测量噪声协方差
static float T = 0.002f;			// 离散时间
// float mx_max = FLT_MIN,mx_min = FLT_MAX;
float mx_max = 3350.0f, mx_min = 2910.0f; // 磁力计X轴的最大值和最小值
// float my_max = FLT_MIN,my_min = FLT_MAX;
float my_max = 2650.0f, my_min = 2100.0f; // 磁力计Y轴的最大值和最小值
// float mz_max = FLT_MIN,mz_min = FLT_MAX;
float mz_max = 3500.0f, mz_min = 2010.0f; // 磁力计Z轴的最大值和最小值

// 卡尔曼姿态解算
void kalman_filter_attitude_solution_calibyaw(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz)
{
	// step1 - 系统输入
	Uk[0] = gx + sin(Xk[0]) * tan(Xk[1]) * gy + cos(Xk[0]) * tan(Xk[1]) * gz;
	Uk[1] = cos(Xk[0]) * gy - sin(Xk[0]) * gz;
	Uk[2] = sin(Xk[0]) * gy / cos(Xk[1]) + cos(Xk[0]) * gz / cos(Xk[1]);

	// step2 - 先验估计
	Xk_[0] = Xk[0] + T * Uk[0];
	Xk_[1] = Xk[1] + T * Uk[1];
	Xk_[2] = Xk[2] + T * Uk[2];

	if (Xk_[2] > 3.141f) // 如果大于PI
	{
		Xk_[2] -= -3.141f * 2.f;
	}
	else if (Xk_[2] < -3.141f) // 如果小于PI
	{
		Xk_[2] += 3.141f * 2.f;
	}

	// step3 - 先验估计误差协方差
	Pk_[0] = Pk[0] + Q[0];
	Pk_[1] = Pk[1] + Q[1];
	Pk_[2] = Pk[2] + Q[2];

	// step4 - 卡尔曼增益
	K[0] = Pk_[0] / (Pk_[0] + R[0]);
	K[1] = Pk_[1] / (Pk_[1] + R[1]);
	K[2] = Pk_[2] / (Pk_[2] + R[2]);

	// step5 - 由磁力计数据计算Yaw
	float mbx, mby, mbz;
	float mZx, mZy; // mZz

	mbx = (mx - (mx_max + mx_min) / 2.f) / ((mx_max - mx_min) / 2.f);
	mby = (my - (my_max + my_min) / 2.f) / ((my_max - my_min) / 2.f);
	mbz = (mz - (mz_max + mz_min) / 2.f) / ((mz_max - mz_min) / 2.f);

	mZx = cos(Xk[1]) * mbx + sin(Xk[1]) * sin(Xk[0]) * mby + sin(Xk[1]) * cos(Xk[0]) * mbz;
	mZy = cos(Xk[0]) * mby - sin(Xk[0]) * mbz;
	// mZz = -sin(Xk[1]) * mbx + cos(Xk[1]) * sin(Xk[0]) * mby + cos(Xk[1]) * cos(Xk[0]) * mbz;

	// step6 - 测量值
	Zk[0] = atan(ay / az);
	Zk[1] = -atan(ax / (sqrt(ay * ay + az * az)));
	Zk[2] = atan2(mZy, mZx);

	// step6 - 后验估计
	Xk[0] = (1 - K[0]) * Xk_[0] + K[0] * Zk[0];
	Xk[1] = (1 - K[1]) * Xk_[1] + K[1] * Zk[1];
	Xk[2] = (1 - K[2]) * Xk_[2] + K[2] * Zk[2];

	// step7 - 后验估计误差协方差
	Pk[0] = (1 - K[0]) * Pk_[0];
	Pk[1] = (1 - K[1]) * Pk_[1];
	Pk[2] = (1 - K[2]) * Pk_[2];

	// 计算结果，单位:°
	roll = Xk[0] / 3.141f * 180.f;
	pitch = Xk[1] / 3.141f * 180.f;
	yaw = Xk[2] / 3.141f * 180.f;
}


/**
 * @brief 将要传输的卡尔曼数据打包
 * @param x 打包数据1，填pitch
 * @param y 打包数据2，填roll
 */
void KalmanData_Packet(float x,float y)
{	
	int i,j;
	uint32_t p_temp=0xFF000000;
	uint32_t r_temp=0xFF000000;
	//pitch,roll都是4字节(32位)，而发送数组为8位，移位操作装入数据
	for(i=0,j=0;i<=3&&j<=7;i++,j++)
	{	
		// TransmitData_Buff[i]=(uint32_t)x&(p_temp);
		// TransmitData_Buff[j]=(uint32_t)y&(r_temp);
		p_temp=p_temp>>8;
		r_temp=r_temp>>8;
	}
}
