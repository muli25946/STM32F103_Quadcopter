#ifndef __PWM_SIMULATE_GAS_H
#define __PWM_SIMULATE_GAS_H

extern int Duty;

void PWM_SIMULATE_GAS_Init(void);//PWM信号脚为PA0

void PWM_SIMULATE_GAS_Min(void);//最小油门
void PWM_SIMULATE_GAS_Max(void);//最大油门
void PWM_SIMULATE_GAS_Mid(void);//50%油门

#endif
