#include "stdint.h"
#ifndef __Software_I2C_
#define __Software_I2C_

void Software_I2C_Init(void);
void Software_I2C_Start(void);
void Software_I2C_Stop(void);
void Software_I2C_SendByte(uint8_t Byte);
uint8_t Software_I2C_ReceiveByte(void);
void Software_I2C_SendAck(uint8_t AckBit);
uint8_t Software_I2C_receiveAck(void);

#endif
