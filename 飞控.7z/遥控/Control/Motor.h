#ifndef __Motor_H
#define __Motor_H

#include "stm32f10x.h"

extern float receive_target_pitch_value;
extern float receive_target_roll_value;

void Motor_SetPWM(void);

#endif
