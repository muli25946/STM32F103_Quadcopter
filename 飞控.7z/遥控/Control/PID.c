#include "stm32f10x.h"
#include "Kalman.h"
#include "PID.h"
#include "Remote.h"

extern float roll,pitch;//Kalaman滤波后的roll pitch数据
extern float pitch_rate,roll_rate;
//接收到的目标角度值
extern float receive_target_pitch_value;//0x00 00 00 00 4字节
extern float receive_target_roll_value;
extern uint8_t ReceivData_Buff[];

CascadePID Quad_PID;

/**
 * @brief 用于初始化pid参数的函数
 * @param pid 结构体参数
 * @param p 比例系数
 * @param i 积分系数
 * @param d 微分系数
 * @param maxI 积分限幅
 * @param maxOut 输出限幅
 */
void PID_Init(PID *pid, float p, float i, float d, float maxI, float maxOut)
{
    pid->kp = p;
    pid->ki = i;
    pid->kd = d;
    pid->maxIntegral = maxI;
    pid->maxOutput = maxOut;
}

/**
 * @brief 进行一次pid计算
 * @param pid PID初始化结构体
 * @param reference 目标值
 * @param feedback 反馈值 
 * @retval 输出结果:PID.output
 */
void PID_Calc(PID *pid, float reference, float feedback)
{
 	//更新数据
    pid->lastError = pid->error; //将旧error存起来
    pid->error = reference - feedback; //计算新error
    //计算微分
    float dout = (pid->error - pid->lastError) * pid->kd;
    //计算比例
    float pout = pid->error * pid->kp;
    //计算积分
    pid->integral += pid->error * pid->ki;
    //积分限幅
    if(pid->integral > pid->maxIntegral) pid->integral = pid->maxIntegral;
    else if(pid->integral < -pid->maxIntegral) pid->integral = -pid->maxIntegral;
    //计算输出
    pid->output = pout+dout + pid->integral;
    //输出限幅
    if(pid->output > pid->maxOutput) pid->output =   pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output = -pid->maxOutput;
}
 
/**
 * @brief 进行一次串级PID的计算
 * @param pid PID初始化结构体
 * @param outerRef 外环目标值
 * @param outerFdb 外环反馈值 
 * @param innerFdb 内环反馈值
 * @retval 内环输出就是串级PID的输出
 */
void PID_CascadeCalc(CascadePID *pid, float outerRef, float outerFdb, float innerFdb)
{
    PID_Calc(&pid->outer, outerRef, outerFdb); //计算外环
    PID_Calc(&pid->inner, pid->outer.output, innerFdb); //计算内环
    pid->output = pid->inner.output; //内环输出就是串级PID的输出
}


//===================================================================================
//Pitch串级PID
/**
 * @brief PID调整pitch
 * @param target_pitch_value 目标pitch角度
 * @param feedback_pitch_value 反馈测量的pitch角度
 * @note 内环:角速度 外环:角度
 */
void Pitch_Accel_PID(float target_pitch_value,float feedback_pitch_value)
{
    PID_Init(&Quad_PID.inner,1,0,0,0,30);
    PID_Init(&Quad_PID.outer,0,0,0,10,20);
    PID_CascadeCalc(&Quad_PID,target_pitch_value,pitch,pitch_rate);
}
//===================================================================================
//Roll串级PID
/**
 * @brief PID调整roll
 * @param target_pitch_value 目标roll角度
 * @param feedback_pitch_value 反馈测量的roll角度
 * @note 内环:角速度 外环:角度
 */
void Roll_Accel_PID(float target_roll_value,float feedback_roll_value)
{ 
    PID_Init(&Quad_PID.inner,0,0,0,0,30);
    PID_Init(&Quad_PID.outer,0,0,0,10,30);
    PID_CascadeCalc(&Quad_PID,target_roll_value,roll,roll_rate);
}


/**
 * @brief 将接收的数据转为float以供计算使用
 * @param i 输入P计算Pitch,输入R计算Roll
 */
void PID_RUN(char i)
{

    float feedback_pitch_value=pitch;
    float feedback_roll_value=roll;

    switch (i)
    {
    case 'P':
        Pitch_Accel_PID(receive_target_pitch_value,feedback_pitch_value);
        break;
    case 'R':
        Roll_Accel_PID(receive_target_roll_value,feedback_roll_value);
        break;
    default:
        break;
    }
}

