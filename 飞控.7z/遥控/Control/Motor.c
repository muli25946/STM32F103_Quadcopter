#include "stm32f10x.h"
#include "PWM.h"
#include "Remote.h"
#include "PID.h"

extern uint8_t ReceivData_Buff[];
extern CascadePID Quad_PID;
extern uint16_t Motor[4];

float receive_target_pitch_value=0;
float receive_target_roll_value=0;
float stand_gas; // 以一个输入值作为基准，PID输出加上这个基准值实现转速差

void Motor_SetPWM(void)
{
    char switch_PID;

    receive_target_pitch_value = ((float)(ReceivData_Buff[1] << 24 | ReceivData_Buff[2] << 16 | ReceivData_Buff[3] << 8 | ReceivData_Buff[4]))-30;
    receive_target_roll_value = ((float)(ReceivData_Buff[5] << 24 | ReceivData_Buff[6] << 16 | ReceivData_Buff[7] << 8 | ReceivData_Buff[8]))-30;
    stand_gas = ((float)(ReceivData_Buff[9] << 24 | ReceivData_Buff[10] << 16 | ReceivData_Buff[11] << 8 | ReceivData_Buff[12]));

    if (stand_gas > 100) // 限制油门大小在50-100
        stand_gas = 100;
    if (stand_gas < 50)
        stand_gas = 50;

    if (receive_target_pitch_value > 30)//目标PITCH限制在-30~30
        receive_target_pitch_value = 30;
    if (receive_target_pitch_value < -30)
        receive_target_pitch_value = -30;

    if (receive_target_roll_value > 30)//目标ROLL限制在-30~30
        receive_target_roll_value = 30;
    if (receive_target_roll_value < -30)
        receive_target_roll_value = -30;

    if (receive_target_pitch_value != 0 && receive_target_roll_value == 0) // 只有pitch输入，没有roll输入
    {
        switch_PID = 'P';
        PID_RUN(switch_PID);
        if(receive_target_pitch_value>0)
        {
            Motor[0] = stand_gas + Quad_PID.inner.output;
        }
        else
        {
            Motor[0] = stand_gas - Quad_PID.inner.output;
        } 
        Motor[1] = Motor[0];
        Motor[2] = stand_gas;
        Motor[3] = Motor[2];
    }
    else if (receive_target_pitch_value == 0 && receive_target_roll_value != 0) // 只有roll输入，没有pitch输入
    {
        switch_PID = 'R';
        PID_RUN(switch_PID);
        if(receive_target_roll_value>0)
        {
            Motor[0] = stand_gas + Quad_PID.inner.output;
        }
        else
        {
            Motor[0] = stand_gas - Quad_PID.inner.output;
        } 
        Motor[0] = stand_gas + Quad_PID.inner.output;
        Motor[3] = Motor[0];
        Motor[2] = stand_gas;
        Motor[1] = Motor[2];
    }
    else if (receive_target_pitch_value == 0 && receive_target_roll_value == 0) // 当没有pitch,roll输入时，仅以油门值作为参考
    {
        Motor[0] = stand_gas;

        for (int i = 1; i <= 3; i++)
        {
            Motor[i] = Motor[0];
        }
    }

    PWM_SetCompare1(Motor[0]);
    PWM_SetCompare2(Motor[1]);
    PWM_SetCompare3(Motor[2]);
    PWM_SetCompare4(Motor[3]);
}
