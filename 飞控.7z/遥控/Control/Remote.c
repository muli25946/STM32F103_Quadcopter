include "stm32f10x.h"
#include "NRF24L01.h"
#include "LED.h"
#include "Kalman.h"
#include "BMP280.h"

extern uint8_t ReceivData_Buff[];
extern uint8_t TransmitData_Buff[];

void Exti_Init(void)
{
    LED_Init(); // 用于指示状态 led1--接收  led2--发送

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE); // 使能复用时钟
    // NRF24L01 NVIC配置
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;      // 打开EXTI15_10全局中断
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;        // 响应优先级为2
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; // 抢占优先级2
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // 使能
    NVIC_Init(&NVIC_InitStructure);                           // NVIC初始化

    // 将GPIO管脚与外部中断线连接
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource12); // 选择GPIOA_Pin_12管脚用作外部中断线路

    // NRF24L01 EXTI配置
    EXTI_InitTypeDef EXTI_InitStructure;
    EXTI_InitStructure.EXTI_Line = EXTI_Line10;             // 外部中断通道12
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     // 中断模式
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; // 下降沿触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;               // 使能
    EXTI_Init(&EXTI_InitStructure);                         // EXTI初始化
    EXTI_ClearITPendingBit(EXTI_Line12);                     // 清除中断线12
}
