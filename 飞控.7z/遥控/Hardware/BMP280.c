#include "stm32f10x.h" // Device header
#include "Hardware_I2C.h"
#include "BMP280_Reg.h"
#include "math.h"

#define BMP280_Address 0xEC  // 写操作地址
#define K_Hypsometric 0.1809 // 定义Hypsometric常数计算高度
#define K_P0 1013.25         // 单位hPa
#define K_Cal 153.84
#define H_Error 40 // 海拔偏差，根据网络数据校准（未验证）

BMP280 bmp280_inst;
BMP280 *bmp280 = &bmp280_inst; // 这个全局结构体变量用来保存存在芯片内ROM补偿参数
double Current_Height;//外部可调用参数，修正后的海拔数据
// extern uint8_t TransmitData_Buff[];

/***********************软件I2C**************************/
// void Hardware_I2C_WriteReg(BMP280_Address,uint8_t reg, uint8_t data)
// {
//     Software_I2C_Start();
//     Software_I2C_SendByte(BMP280_Address);
//     Software_I2C_receiveAck();
//     Software_I2C_SendByte(reg);
//     Software_I2C_receiveAck();

//     Software_I2C_SendByte(data);
//     Software_I2C_receiveAck();
//     Software_I2C_Stop();
// }

// static uint8_t Hardware_I2C_ReadReg(BMP280_Address,uint8_t reg)
// {
//     uint8_t rec_data;
//     Software_I2C_Start();
//     Software_I2C_SendByte(BMP280_Address);
//     Software_I2C_receiveAck();
//     Software_I2C_SendByte(reg);
//     Software_I2C_receiveAck();

//     Software_I2C_Start();
//     Software_I2C_SendByte(BMP280_Address | 0x01);
//     Software_I2C_receiveAck();
//     rec_data = Software_I2C_ReceiveByte(); // 不应答
//     Software_I2C_Stop();
//     return rec_data;
// }
/***********************软件I2C**************************/

void BMP280_Init(void)
{
    Hardware_I2C_Init();
    uint8_t Lsb, Msb;

    /********************接下来读出矫正参数*********************/
    // 温度传感器的矫正值
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T1_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T1_MSB_REG);
    bmp280->T1 = (((u16)Msb) << 8) + Lsb; // 高位加低位
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T2_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T2_MSB_REG);
    bmp280->T2 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T3_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_T3_MSB_REG);
    bmp280->T3 = (((u16)Msb) << 8) + Lsb;

    // 大气压传感器的矫正值
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P1_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P1_MSB_REG);
    bmp280->P1 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P2_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P2_MSB_REG);
    bmp280->P2 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P3_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P3_MSB_REG);
    bmp280->P3 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P4_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P4_MSB_REG);
    bmp280->P4 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P5_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P5_MSB_REG);
    bmp280->P5 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P6_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P6_MSB_REG);
    bmp280->P6 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P7_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P7_MSB_REG);
    bmp280->P7 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P8_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P8_MSB_REG);
    bmp280->P8 = (((u16)Msb) << 8) + Lsb;
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P9_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_DIG_P9_MSB_REG);
    bmp280->P9 = (((u16)Msb) << 8) + Lsb;
    /******************************************************/
    Hardware_I2C_WriteReg(BMP280_Address, BMP280_RESET_REG, BMP280_RESET_VALUE); // 往复位寄存器写入给定值

    BMP_OVERSAMPLE_MODE BMP_OVERSAMPLE_MODEStructure;
    BMP_OVERSAMPLE_MODEStructure.P_Osample = BMP280_P_MODE_3;
    BMP_OVERSAMPLE_MODEStructure.T_Osample = BMP280_T_MODE_1;
    BMP_OVERSAMPLE_MODEStructure.WORKMODE = BMP280_NORMAL_MODE;
    BMP280_Set_TemOversamp(&BMP_OVERSAMPLE_MODEStructure);

    BMP_CONFIG BMP_CONFIGStructure;
    BMP_CONFIGStructure.T_SB = BMP280_T_SB1;
    BMP_CONFIGStructure.FILTER_COEFFICIENT = BMP280_FILTER_MODE_4;
    BMP_CONFIGStructure.SPI_EN = DISABLE;

    BMP280_Set_Standby_FILTER(&BMP_CONFIGStructure);
}
// 设置BMP过采样因子 MODE
// BMP280_SLEEP_MODE||BMP280_FORCED_MODE||BMP280_NORMAL_MODE
void BMP280_Set_TemOversamp(BMP_OVERSAMPLE_MODE *Oversample_Mode)
{
    uint8_t Regtmp;
    Regtmp = ((Oversample_Mode->T_Osample) << 5) |
             ((Oversample_Mode->P_Osample) << 2) |
             ((Oversample_Mode)->WORKMODE);

    Hardware_I2C_WriteReg(BMP280_Address, BMP280_CTRLMEAS_REG, Regtmp);
}

// 设置保持时间和滤波器分频因子
void BMP280_Set_Standby_FILTER(BMP_CONFIG *BMP_Config)
{
    uint8_t Regtmp;
    Regtmp = ((BMP_Config->T_SB) << 5) |
             ((BMP_Config->FILTER_COEFFICIENT) << 2) |
             ((BMP_Config->SPI_EN));

    Hardware_I2C_WriteReg(BMP280_Address, BMP280_CONFIG_REG, Regtmp);
}

// 获取BMP当前状态 原始值
// status_flag = BMP280_MEASURING ||
//			 	BMP280_IM_UPDATE
uint8_t BMP280_GetStatus(uint8_t status_flag)
{
    uint8_t flag;
    flag = Hardware_I2C_ReadReg(BMP280_Address, BMP280_STATUS_REG);
    if (flag & status_flag)
        return SET;
    else
        return RESET;
}

/**
 * @brief 返回BMP280的ID号
 * @param 无
 * @retval BMP280的设备ID
 */
uint8_t BMP280_ReadID(void)
{
    return Hardware_I2C_ReadReg(BMP280_Address, BMP280_CHIPID_REG);
}
/*******************主要部分*********************/
/****************获取传感器精确值****************/
// 大气压值-Pa
/**************************传感器值转定点值*************************************/
BMP280_S32_t t_fine; // 用于计算补偿
// 我用浮点补偿
#ifdef USE_FIXED_POINT_COMPENSATE
// Returns temperature in DegC, resolution is 0.01 DegC. Output value of “5123” equals 51.23 DegC.
// t_fine carries fine temperature as global value
BMP280_S32_t bmp280_compensate_T_int32(BMP280_S32_t adc_T)
{
    BMP280_S32_t var1, var2, T;
    var1 = ((((adc_T >> 3) - ((BMP280_S32_t)dig_T1 << 1))) * ((BMP280_S32_t)dig_T2)) >> 11;
    var2 = (((((adc_T >> 4) - ((BMP280_S32_t)dig_T1)) * ((adc_T >> 4) - ((BMP280_S32_t)dig_T1))) >> 12) *
            ((BMP280_S32_t)dig_T3)) >>
           14;
    t_fine = var1 + var2;
    T = (t_fine * 5 + 128) >> 8;
    return T;
}

// Returns pressure in Pa as unsigned 32 bit integer in Q24.8 format (24 integer bits and 8 fractional bits).
// Output value of “24674867” represents 24674867/256 = 96386.2 Pa = 963.862 hPa
BMP280_U32_t bmp280_compensate_P_int64(BMP280_S32_t adc_P)
{
    BMP280_S64_t var1, var2, p;
    var1 = ((BMP280_S64_t)t_fine) - 128000;
    var2 = var1 * var1 * (BMP280_S64_t)dig_P6;
    var2 = var2 + ((var1 * (BMP280_S64_t)dig_P5) << 17);
    var2 = var2 + (((BMP280_S64_t)dig_P4) << 35);
    var1 = ((var1 * var1 * (BMP280_S64_t)dig_P3) >> 8) + ((var1 * (BMP280_S64_t)dig_P2) << 12);
    var1 = (((((BMP280_S64_t)1) << 47) + var1)) * ((BMP280_S64_t)dig_P1) >> 33;
    if (var1 == 0)
    {
        return 0; // avoid exception caused by division by zero
    }
    p = 1048576 - adc_P;
    p = (((p << 31) - var2) * 3125) / var1;
    var1 = (((BMP280_S64_t)dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((BMP280_S64_t)dig_P8) * p) >> 19;
    p = ((p + var1 + var2) >> 8) + (((BMP280_S64_t)dig_P7) << 4);
    return (BMP280_U32_t)p;
}

/***********************************CUT*************************************/
#else
/**************************传感器值转定点值*************************************/
// Returns temperature in DegC, double precision. Output value of “51.23” equals 51.23 DegC.
// t_fine carries fine temperature as global value
double bmp280_compensate_T_double(BMP280_S32_t adc_T)
{
    double var1, var2, T;
    var1 = (((double)adc_T) / 16384.0 - ((double)dig_T1) / 1024.0) * ((double)dig_T2);
    var2 = ((((double)adc_T) / 131072.0 - ((double)dig_T1) / 8192.0) *
            (((double)adc_T) / 131072.0 - ((double)dig_T1) / 8192.0)) *
           ((double)dig_T3);
    t_fine = (BMP280_S32_t)(var1 + var2);
    T = (var1 + var2) / 5120.0;
    return T;
}

// Returns pressure in Pa as double. Output value of “96386.2” equals 96386.2 Pa = 963.862 hPa
double bmp280_compensate_P_double(BMP280_S32_t adc_P)
{
    double var1, var2, p;
    var1 = ((double)t_fine / 2.0) - 64000.0;
    var2 = var1 * var1 * ((double)dig_P6) / 32768.0;
    var2 = var2 + var1 * ((double)dig_P5) * 2.0;
    var2 = (var2 / 4.0) + (((double)dig_P4) * 65536.0);
    var1 = (((double)dig_P3) * var1 * var1 / 524288.0 + ((double)dig_P2) * var1) / 524288.0;
    var1 = (1.0 + var1 / 32768.0) * ((double)dig_P1);
    if (var1 == 0.0)
    {
        return 0; // avoid exception caused by division by zero
    }
    p = 1048576.0 - (double)adc_P;
    p = (p - (var2 / 4096.0)) * 6250.0 / var1;
    var1 = ((double)dig_P9) * p * p / 2147483648.0;
    var2 = p * ((double)dig_P8) / 32768.0;
    p = p + (var1 + var2 + ((double)dig_P7)) / 16.0;
    return p;
}
#endif

/**
 * @brief BMP280返回气压值
 * @param 无
 * @retval 气压(单位:Pa)
 */
double BMP280_Get_Pressure(void)
{
    uint8_t XLsb, Lsb, Msb;
    long signed Bit32;
    double pressure;
    XLsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_PRESSURE_XLSB_REG);
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_PRESSURE_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_PRESSURE_MSB_REG);
    Bit32 = ((long)(Msb << 12)) | ((long)(Lsb << 4)) | (XLsb >> 4); // 寄存器的值,组成一个浮点数
    pressure = bmp280_compensate_P_double(Bit32);
    return pressure;
}

/**
 * @brief BMP280返回摄氏度
 * @param 无
 * @retval 温度(单位:℃)
 */
double BMP280_Get_Temperature(void)
{
    uint8_t XLsb, Lsb, Msb;
    long signed Bit32;
    double temperature;
    XLsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_TEMPERATURE_XLSB_REG);
    Lsb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_TEMPERATURE_LSB_REG);
    Msb = Hardware_I2C_ReadReg(BMP280_Address, BMP280_TEMPERATURE_MSB_REG);
    Bit32 = ((long)(Msb << 12)) | ((long)(Lsb << 4)) | (XLsb >> 4); // 寄存器的值,组成一个浮点数
    temperature = bmp280_compensate_T_double(Bit32);
    return temperature;
}

/**
 * @brief BMP280返回海拔高度(根据zh-cn.topographic-map.com矫正误差)
 * @param 无
 * @retval 矫正后的海拔值，单位:米
 */
void BMP280_Get_Height(void)
{
    double H_P, T;
    double Height;
    H_P = BMP280_Get_Pressure() / 100.00;
    T = BMP280_Get_Temperature();
    Height = ((pow((K_P0 / H_P), K_Hypsometric)) - 1) * (T + 273.15) * K_Cal;
    Current_Height = Height - H_Error;
}

/**
 * @brief 将要传输的高度数据打包
 * @param x 打包数据，填Current_Height
 */
void BMP280Data_Packet(double x)
{	
	int i;
	uint64_t b_temp=0xFF000000;//0xFF00 0000
	//Current是8字节(64位)，而发送数组为8位，移位操作装入数据
	for(i=8;i<=15;i++)
	{	
		// TransmitData_Buff[i]=(uint64_t)x&(b_temp);
		b_temp=b_temp>>8;
	}
}
