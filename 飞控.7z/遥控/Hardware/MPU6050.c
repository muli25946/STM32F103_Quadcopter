#include "stm32f10x.h"
#include "Hardware_I2C.h"
#include "MPU6050_Reg.h"
#include "math.h"

#define MPU6050_Address 0xD0

float pitch_raw; // 俯仰角pitch原始数据
float roll_raw;	 // 横滚角roll原始数据

float pitch_rate;//pitch角速率
float roll_rate;//roll角速率

/*软件I2C系列，速率不可控，已搁置
////MPU6050写寄存器////
void MPU6050_WriteReg(uint8_t RegAddress,uint8_t Data)
{
	Software_I2C_Start();
	Software_I2C_SendByte(MPU6050_Address);
	Software_I2C_receiveAck();
	Software_I2C_SendByte(RegAddress|0x00);
	Software_I2C_receiveAck();
	Software_I2C_SendByte(Data);
	Software_I2C_receiveAck();
	Software_I2C_Stop();
}

////MPU6050读寄存器////
	uint8_t MPU6050_ReadReg(uint8_t RegAddress)
{   uint8_t Data=0x00;
	Software_I2C_Start();
	Software_I2C_SendByte(MPU6050_Address);
	Software_I2C_receiveAck();
	Software_I2C_SendByte(RegAddress|0x00);
	Software_I2C_receiveAck();

	Software_I2C_Start();
	Software_I2C_SendByte(MPU6050_Address|0x01);
	Software_I2C_receiveAck();
	Data= Software_I2C_ReceiveByte();
	Software_I2C_SendAck(1);
	Software_I2C_Stop();
	return Data;
}
*/

void MPU6050_Init()
{
	/*软件I2C初始化配置MPU6050
		////MPU6050寄存器配置////
		MPU6050_WriteReg(MPU6050_PWR_MGMT_1,0x01);
		MPU6050_WriteReg(MPU6050_PWR_MGMT_2,0x00);
		// MPU6050_WriteReg(MPU6050_USER_CTRL,0x00);//该寄存器位5置0，允许启用旁路模式，默认值0x00
		MPU6050_WriteReg(MPU6050_INT_PIN_CFG,0x02);//旁路模式
		MPU6050_WriteReg(MPU6050_SMPLRT_DIV,0x09);
		MPU6050_WriteReg(MPU6050_CONFIG,0x06);
		MPU6050_WriteReg(MPU6050_GYRO_CONFIG,0x18);
		MPU6050_WriteReg(MPU6050_ACCEL_CONFIG,0x18);
		*/
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_PWR_MGMT_1, 0x01);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_PWR_MGMT_2, 0x00);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_USER_CTRL, 0x00);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_INT_PIN_CFG, 0x02);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_SMPLRT_DIV, 0x09);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_CONFIG, 0x06);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_GYRO_CONFIG, 0x18);
	Hardware_I2C_WriteReg(MPU6050_Address, MPU6050_ACCEL_CONFIG, 0x01);
}

/**
 * @brief 返回MPU6050的ID号
 * @param 无
 * @retval MPU6050的设备ID
 */
uint8_t MPU6050_GetID()
{
	return Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_WHO_AM_I);
}

/**
 * @brief 返回MPU6050读取到的三轴加速度数据
 * @param Acc_X 接X轴加速度变量的地址
 * @param Acc_Y 接Y轴加速度变量的地址
 * @param Acc_Z 接Z轴加速度变量的地址
 * @retval 指针传递，无返回值
 */
void MPU6050_GetAccel(int16_t *Acc_X, int16_t *Acc_Y, int16_t *Acc_Z)
{
	*Acc_X = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_XOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_XOUT_L);
	*Acc_Y = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_YOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_YOUT_L);
	*Acc_Z = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_ZOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_ACCEL_ZOUT_L);
}

/**
 * @brief 返回MPU6050读取到的三轴陀螺仪数据
 * @param Gyro_X 接X轴陀螺仪变量的地址
 * @param Gyro_Y 接Y轴陀螺仪变量的地址
 * @param Gyro_Z 接Z轴陀螺仪变量的地址
 * @retval 指针传递，无返回值
 */
void MPU6050_GetGyro(int16_t *Gyro_X, int16_t *Gyro_Y, int16_t *Gyro_Z)
{
	*Gyro_X = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_XOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_XOUT_L);
	*Gyro_Y = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_YOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_YOUT_L);
	*Gyro_Z = (Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_ZOUT_H) << 8) | Hardware_I2C_ReadReg(MPU6050_Address, MPU6050_GYRO_ZOUT_L);
}

/**
 * @brief MPU6050对获得的原数据处理
 * @param 无
 * @retval extern调用，详见MPU6050.h
 * @note 该函数调用后pitch_raw,roll_raw才有值
 */
void MPU6050_Cal(void)
{
	// 1. 原始数据获取
	float accx, accy, accz; // 三方向角加速度值
	float accel_x,accel_y,accel_z;
	float gyro_x,gyro_y,gyro_z;
	int16_t ax, ay, az;		// 三轴加速度
	int16_t gx, gy, gz;		// 三轴陀螺仪

	MPU6050_GetAccel(&ax, &ay, &az); // h获取加速度值
	MPU6050_GetGyro(&gx, &gy, &gz);	 // 获取陀螺仪值

	accel_x = ax; // x轴加速度值暂存
	accel_y = ay; // y轴加速度值暂存
	accel_z = az; // z轴加速度值暂存

	gyro_x = gx; // x轴陀螺仪值暂存
	gyro_y = gy; // y轴陀螺仪值暂存
	gyro_z = gz; // z轴陀螺仪值暂存

	// 2.角加速度原始值处理过程
	// 加速度传感器配置寄存器0X1C内写入0x01,设置范围为±2g。换算关系：2^16/4 = 16384LSB/g
	if (accel_x < 32764)
		accx = accel_x / 16384.0; // 计算x轴加速度
	else
		accx = 1 - (accel_x - 49152) / 16384.0;
	if (accel_y < 32764)
		accy = accel_y / 16384.0; // 计算y轴加速度
	else
		accy = 1 - (accel_y - 49152) / 16384.0;
	if (accel_z < 32764)
		accz = accel_z / 16384.0; // 计算z轴加速度
	else
		accz = (accel_z - 49152) / 16384.0;
	// 加速度反正切公式计算三个轴和水平面坐标系之间的夹角
	pitch_raw = (atan(accy / accz)) * 180 / 3.14;
	roll_raw = (atan(accx / accz)) * 180 / 3.14;
	// 判断计算后角度的正负号
	if (accel_x < 32764)
		roll_raw = +roll_raw;
	if (accel_x > 32764)
		roll_raw = -roll_raw;
	if (accel_y < 32764)
		pitch_raw = +pitch_raw;
	if (accel_y > 32764)
		pitch_raw = -pitch_raw;

	// 3.原始值处理过程
	// 陀螺仪配置寄存器0X1B内写入0x18，设置范围为±2000deg/s。换算关系：2^16/4000=16.4LSB/(°/S)
	////计算
	if (gyro_x < 32768)
		gyro_x = -(gyro_x / 16.4);
	if (gyro_x > 32768)
		gyro_x = +(65535 - gyro_x) / 16.4;
	if (gyro_y < 32768)
		gyro_y = -(gyro_y / 16.4);
	if (gyro_y > 32768)
		gyro_y = +(65535 - gyro_y) / 16.4;
	if (gyro_z < 32768)
		gyro_z = -(gyro_z / 16.4);
	if (gyro_z > 32768)
		gyro_z = +(65535 - gyro_z) / 16.4;
}

//===========================================================================================
//角速度= 角速度原始值/分辨率

void pitch_roll_RateCal(void)
{	
	int16_t gx,gy,gz;

	float gyro_x,gyro_y,gyro_z;

	MPU6050_GetGyro(&gx,&gy,&gz);
	gyro_x=gx;
	gyro_y=gy;
	gyro_z=gz;

	pitch_rate=gyro_y/16.384;
	roll_rate=gyro_x/16.384;
	gyro_z/=1.0f;//这句没啥用，单纯为了消除警告提示
}
