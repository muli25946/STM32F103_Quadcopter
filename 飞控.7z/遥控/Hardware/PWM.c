/*频率Freq = CK_PSC / (PSC + 1) / (ARR + 1)
 *占空比Duty = CCR / (ARR + 1)
 */
#include "stm32f10x.h"

void PWM_Init(uint16_t ARR, uint16_t PSC)
{
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);  // 开启TIM2时钟
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 开启GPIOA时钟

  /*GPIO重映射*/
  // RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);			//开启AFIO的时钟，重映射必须先开启AFIO的时钟
  // GPIO_PinRemapConfig(GPIO_PartialRemap1_TIM2, ENABLE);			//将TIM2的引脚部分重映射，具体的映射方案需查看参考手册
  // GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);		//将JTAG引脚失能，作为普通GPIO引脚使用

  /*GPIO初始化*/
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /*配置时钟源*/
  TIM_InternalClockConfig(TIM2);
  //=================================================================================
  // 电调需要50Hz信号(T=20ms) 0%油门->5%Duty(compare=500) 100%油门->10%Duty(compare=1000)
  //=================================================================================
  /*时基单元初始化*/
  TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
  TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;     // 时钟分频(1为不分频，72MHZ)
  TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; // 计数器模式
  TIM_TimeBaseInitStructure.TIM_Period = ARR - 1;                 // 计数周期，即ARR的值:重装载数 (16位寄存器，有效值1~65535)。ARR为1000方便计算占空比(Compare取500-1000)
  TIM_TimeBaseInitStructure.TIM_Prescaler = PSC - 1;              // 预分频器，即PSC的值,电调需要50Hz信号。此处固定
  TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;            // 重复计数器，高级定时器才会用到
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

  /*输出比较初始化*/
  TIM_OCInitTypeDef TIM_OCInitStructure;
  TIM_OCStructInit(&TIM_OCInitStructure); // 结构体初始化，若结构体没有完整赋值,则最好执行此函数，给结构体所有成员都赋一个默认值,避免结构体初值不确定的问题

  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;             // 输出比较模式
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;     // 输出极性
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // 输出使能
  TIM_OCInitStructure.TIM_Pulse = 0;                            // 初始的CCR值

  TIM_OC1Init(TIM2, &TIM_OCInitStructure);
  TIM_OC2Init(TIM2, &TIM_OCInitStructure);
  TIM_OC3Init(TIM2, &TIM_OCInitStructure);
  TIM_OC4Init(TIM2, &TIM_OCInitStructure);

  /*TIM使能*/
  TIM_Cmd(TIM2, ENABLE);
}

/**
 * 函    数：PWM设置CCR1
 * 参    数：Compare 要写入的CCR1的值
 * 返 回 值：无
 * 注意事项：CCR和ARR共同决定占空比，此函数仅设置CCR1的值，并不直接是占空比
 *           占空比Duty = CCR1 / (ARR + 1)
 */
void PWM_SetCompare1(uint16_t Compare)
{
  TIM_SetCompare1(TIM2, Compare); // 设置CCR1的值
}

/**
 * 函    数：PWM设置CCR2
 * 参    数：Compare 要写入的CCR2的值
 * 返 回 值：无
 * 注意事项：CCR和ARR共同决定占空比，此函数仅设置CCR2的值，并不直接是占空比
 *           占空比Duty = CCR2 / (ARR + 1)
 */
void PWM_SetCompare2(uint16_t Compare)
{
  TIM_SetCompare2(TIM2, Compare); // 设置CCR2的值
}
/**
 * 函    数：PWM设置CCR3
 * 参    数：Compare 要写入的CCR3的值
 * 返 回 值：无
 * 注意事项：CCR和ARR共同决定占空比，此函数仅设置CCR1的值，并不直接是占空比
 *           占空比Duty = CCR3 / (ARR + 1)
 */
void PWM_SetCompare3(uint16_t Compare)
{
  TIM_SetCompare3(TIM2, Compare); // 设置CCR3的值
}
/**
 * 函    数：PWM设置CCR4
 * 参    数：Compare 要写入的CCR4的值
 * 返 回 值：无
 * 注意事项：CCR和ARR共同决定占空比，此函数仅设置CCR4的值，并不直接是占空比
 *           占空比Duty = CCR4 / (ARR + 1)
 */
void PWM_SetCompare4(uint16_t Compare)
{
  TIM_SetCompare4(TIM2, Compare); // 设置CCR4的值
}

/**
 * 函    数：PWM设置PSC
 * 参    数：Prescaler 要写入的PSC的值，范围：0~65535
 * 返 回 值：无
 * 注意事项：PSC和ARR共同决定频率，此函数仅设置PSC的值，并不直接是频率
 *           频率Freq = CK_PSC / (PSC + 1) / (ARR + 1)
 */
void PWM_SetPrescaler(uint16_t Prescaler)
{
  TIM_PrescalerConfig(TIM2, Prescaler, TIM_PSCReloadMode_Immediate); // 设置PSC的值
}
