#include "stm32f10x.h"
#include "QMC5883L_Reg.h"
#include "Hardware_I2C.h"
#include "math.h"

#define QMC5883L_Address 0x1A
extern float pitch_raw;		        // 俯仰角pitch原始数据
extern float roll_raw;			    // 横滚角roll原始数据

void QMC5883L_Init(void)
{
    Hardware_I2C_Init();

    Hardware_I2C_WriteReg(QMC5883L_Address, QMC5883L_Control, 0xD5); // 模式:连续模式，50Hz频率，8G量程，512过采样率
}

/**
 * @brief QMC5883L返回读取到的原始数据
 * @param Mag_X 接收X值的变量地址
 * @param Mag_Y 接收Y值的变量地址
 * @param Mag_Z 接收Z值的变量地址
 * @retval 无，通过指针返回
 */
void QMC5883L_Get_MagData(int16_t *Mag_X, int16_t *Mag_Y, int16_t *Mag_Z)
{
    *Mag_X = (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_X_MSB) << 8) | (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_X_LSB));
    *Mag_Y = (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_Y_MSB) << 8) | (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_Y_LSB));
    *Mag_Z = (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_Z_MSB) << 8) | (Hardware_I2C_ReadReg(QMC5883L_Address, QMC5883L_Z_LSB));
}
