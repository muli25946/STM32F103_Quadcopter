#include "stm32f10x.h"
#include "Hardware_I2C.h"
#include "Delay.h"
// #include "OLED.h"
#include "PWM.h"
#include "LED.h"
#include "MPU6050.h"
#include "QMC5883L.h"
#include "BMP280.h"
#include "NRF24L01.h"
#include "Kalman.h"
#include "Remote.h"
#include "Motor.h"

uint16_t Motor[4]={0};

uint8_t ReceivData_Buff[32] = {0};
// uint8_t TransmitData_Buff[32] = {12};

int main(void)
{
	// SystemInit();
	Hardware_I2C_Init();
	// OLED_Init();
	PWM_Init(1000,1440);
	LED_Init();
	MPU6050_Init();
	QMC5883L_Init();
	BMP280_Init();
	NRF24L01_Init();
	LED1_ON(); // 初始化完成指示灯

	float gx, gy, gz, ax, ay, az, mx, my, mz;
	int16_t igx, igy, igz, iax, iay, iaz, imx, imy, imz;
	Delay_ms(1000);
	Delay_ms(1000);
	Delay_ms(1000);
	Delay_ms(1000);
	while (1)
	{
		//=======================================================================
		// 初始数据获取
		MPU6050_GetAccel(&iax, &iay, &iaz);
		MPU6050_GetAccel(&igx, &igy, &igz);
		QMC5883L_Get_MagData(&imx, &imy, &imz);
		BMP280_Get_Height();
		gx = igx;gy = igy;gz = igz;
		ax = iax;ay = iay;az = iaz;
		mx = imx;	my = imy;mz = imz;

		// 卡尔曼解算姿态
		kalman_filter_attitude_solution_calibyaw(gx, gy, gz, ax, ay, az, mx, my, mz);
		// MPU6050计算角速度
		pitch_roll_RateCal();
		// PID计算结果通过PWM控制
		if (NRF24L01_Get_Value_Flag() == 0)
		{
			NRF24L01_GetRxBuf(ReceivData_Buff);
			LED2_Turn();
		}
		Motor_SetPWM();
		LED1_Turn();
	}
}
