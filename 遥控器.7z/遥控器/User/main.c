#include "stm32f10x.h" // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include "NRF24L01.h"
#include "AD.h"
#include "Timer.h"
#include "Transfor.h"
// #include "Remote.h"

extern float OLED_NUM[];
extern uint32_t AD_Value[];
extern float temp[];

uint8_t TransmitData_Buff[32] = {12};
int timer_cnt = 0;

int main(void)
{
	// SystemInit();
	OLED_Init();
	OLED_ShowString(1, 1, "Be Initializing");
	LED_Init();
	NRF24L01_Init();
	Timer4_Init(1000,7200);//ARR 10000,PSC 7200:10Hz
	AD_Init();

	OLED_Clear();
	OLED_ShowString(1, 1, "OK!!!");
	OLED_Clear();
	OLED_ShowString(1, 1, "P:");
	OLED_ShowString(2, 1, "R:");
	OLED_ShowString(3, 1, "G:");
	OLED_ShowString(3,6,"%");

	while (1)
	{
		AD_To_TxPacket();
		Tx_To_OLED();
		if (timer_cnt > 10)
		{
			NRF24L01_SendBuf(TransmitData_Buff);
			LED1_Turn();
			timer_cnt = 0;
		}
		OLED_ShowSignedNum(1, 4, OLED_NUM[0], 4);
		OLED_ShowSignedNum(2, 4, OLED_NUM[1], 4);
		OLED_ShowNum(3, 3, OLED_NUM[4], 3);
	}
}

void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
		//OLED_ShowString(4,1,"IRQ");//判断是否进中断
		timer_cnt++;
	}
}
