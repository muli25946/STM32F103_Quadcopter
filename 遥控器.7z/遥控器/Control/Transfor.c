#include "stm32f10x.h"

extern uint8_t TransmitData_Buff[];

float OLED_NUM[5];

// uint32_t转float
float U32ToFloat(u32 dat)
{
	u8 buf[4];

	buf[0] = dat >> 24;
	buf[1] = dat >> 16;
	buf[2] = dat >> 8;
	buf[3] = dat & 0xff;

	return *((float *)buf);
}

// float转uint32_t
u32 FloatToU32(float dat)
{
	u8 buf[4];

	buf[0] = ((u8 *)&dat)[0];
	buf[1] = ((u8 *)&dat)[1];
	buf[2] = ((u8 *)&dat)[2];
	buf[3] = ((u8 *)&dat)[3];

	return (buf[0] << 24) + (buf[1] << 16) + (buf[2] << 8) + buf[3];
}

/**
 * @brief 将发送的数据显示在遥控器OLED上,也可以检查接收端接收数据是否符合预期
 * @note 接收端使用相同方法解算接收的数据
 */
void Tx_To_OLED(void)
{
	OLED_NUM[0] = ((float)(TransmitData_Buff[1] << 24 | TransmitData_Buff[2] << 16 | TransmitData_Buff[3] << 8 | TransmitData_Buff[4]))-30;	  // PITCH
	OLED_NUM[1] = ((float)(TransmitData_Buff[5] << 24 | TransmitData_Buff[6] << 16 | TransmitData_Buff[7] << 8 | TransmitData_Buff[8])-30);	  // ROLL
	OLED_NUM[2] = (float)(TransmitData_Buff[9] << 24 | TransmitData_Buff[10] << 16 | TransmitData_Buff[11] << 8 | TransmitData_Buff[12]); // GAS
	// OLED_NUM[3]=(float)(TransmitData_Buff[13]<<24|TransmitData_Buff[14]<<16|TransmitData_Buff[15]<<8|TransmitData_Buff[16]);//YAW
	OLED_NUM[4]=2*OLED_NUM[2]-100;//GAS的百分比形式
}
