#ifndef __Remote_H
#define __Remote_H
#include "stm32f10x.h"

extern uint8_t ReceivData_Buff[];
extern uint8_t TransmitData_Buff[];

void Remote_Init(void);
void TIM4_IRQHandler(void);

#endif
