#ifndef __Transfor_H
#define __Transfor_H
#include "stm32f10x.h"

extern float OLED_NUM[];

float U32ToFloat(u32 dat);
u32 FloatToU32(float dat);
void Tx_To_OLED(void);

#endif
