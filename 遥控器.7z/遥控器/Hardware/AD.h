#ifndef __AD_H
#define __AD_H
#include "stm32f10x.h"

extern uint32_t AD_Value[4];
extern float temp[4];

void AD_Init(void);
void AD_filter(void);
void AD_To_TxPacket(void);

#endif
