#include "stm32f10x.h" // Device header
#include "math.h"
#include "Remote.h"
#include "AD.h"
#include "Transfor.h"

#define K_G 0.122549 // AD值线性转换为油门值(50.0~100)
#define K_P 0.146842 // AD值线性转换为角度(-30~30)
#define K_R 0.146806 // AD值线性转换为角度(-30~30)

uint32_t AD_Value[4];		  // 定义用于存放AD转换结果的全局数组 0-PITCH;1-ROLL;2-GAS;3-YAW
uint32_t Last_Value[4] = {0}; // 上一次的值

float temp[4]; // 建立临时变量进行浮点运算，运算结束将其转为u32发送
// extern uint8_t ReceivData_Buff[];
extern uint8_t TransmitData_Buff[];
int cnt = 0;

#define ADError 1.0 // AD滤波偏差值

/**
 *@brief AD初始化
 *@param 无
 *@retval 无
 */
void AD_Init(void)
{
	//===========================================================================================
	// GPIO初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 开启GPIOA的时钟

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure); // 将PA0、PA1、PA2和PA3引脚初始化为模拟输入

	//===========================================================================================
	// ADC初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // 开启ADC1的时钟
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);					 // 设置ADC时钟选择时钟6分频，ADCCLK = 72MHz / 6 = 12MHz

	ADC_InitTypeDef ADC_InitStructure;											// 定义结构体变量
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;							// 模式，选择独立模式，即单独使用ADC1
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;						// 数据对齐，选择右对齐
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;			// 外部触发，使用软件触发，不需要外部触发
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;							// 连续转换，使能，每转换一次规则组序列后立刻开始下一次转换
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;								// 扫描模式，使能，扫描规则组的序列，扫描数量由ADC_NbrOfChannel确定
	ADC_InitStructure.ADC_NbrOfChannel = 4;										// 通道数，为4，扫描规则组的前4个通道
	ADC_Init(ADC1, &ADC_InitStructure);											// 将结构体变量交给ADC_Init，配置ADC1
	/*规则组通道配置*/															// 发送数据包 PITCH(4Byte)|ROLL(4Byte)|GAS(4Byte)
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 1, ADC_SampleTime_55Cycles5); // 通道3(PA3)，配置为规则组序列1的位置--PITCH
	ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 2, ADC_SampleTime_55Cycles5); // 通道2(PA2)，配置为规则组序列2的位置--ROLL
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 3, ADC_SampleTime_55Cycles5); // 通道0(PA0)，配置为规则组序列3的位置--GAS
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 4, ADC_SampleTime_55Cycles5); // 通道1(PA1)，配置为规则组序列4的位置--YAW

	//===========================================================================================
	// DMA初始化
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); // 开启DMA1的时钟

	DMA_InitTypeDef DMA_InitStructure;										// 定义结构体变量
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;			// 外设基地址，给定形参AddrA
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word; // 外设数据宽度，选择全字，对应32位的ADC数据寄存器(对应上飞控接收数据)
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;		// 外设地址自增，选择失能，始终以ADC数据寄存器为源
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)AD_Value;				// 存储器基地址，给定存放AD转换结果的全局数组AD_Value
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;			// 存储器数据宽度，选择全字，与源数据宽度对应
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;					// 存储器地址自增，选择使能，每次转运后，数组移到下一个位置
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;						// 数据传输方向，选择由外设到存储器，ADC数据寄存器转到数组
	DMA_InitStructure.DMA_BufferSize = 4;									// 转运的数据大小（转运次数），与ADC通道数一致
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;							// 模式，选择循环模式，与ADC的连续转换一致
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;							// 存储器到存储器，选择失能，数据由ADC外设触发转运到存储器
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;					// 优先级，选择中等
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);							// 将结构体变量交给DMA_Init，配置DMA1的通道1

	//===========================================================================================
	// DMA和ADC使能
	DMA_Cmd(DMA1_Channel1, ENABLE); // DMA1的通道1使能
	ADC_DMACmd(ADC1, ENABLE);		// ADC1触发DMA1的信号使能
	ADC_Cmd(ADC1, ENABLE);			// ADC1使能

	// ADC校准
	ADC_ResetCalibration(ADC1); // 固定流程，内部有电路会自动执行校准
	while (ADC_GetResetCalibrationStatus(ADC1) == SET)
		;

	ADC_StartCalibration(ADC1);
	while (ADC_GetCalibrationStatus(ADC1) == SET)
		;

	// ADC触发
	ADC_SoftwareStartConvCmd(ADC1, ENABLE); // 软件触发ADC开始工作，由于ADC处于连续转换模式，故触发一次后ADC就可以一直连续不断地工作
}

/**
 * @brief 限幅滤波
 * @note 判断误差根据实际情况修改，该方法不适合快速变化
 */
void AD_filter(void)
{
	uint32_t New_Value[4]; // 新的值

	// 将第一次获得的AD值给Last_Value,第一次滤波无效
	if (cnt == 0)
	{
		for (int i = 0; i < 4; i++)
		{
			Last_Value[i] = AD_Value[i];
		}
		cnt++;
	}

	for (int j = 0; j < 4; j++)
	{
		New_Value[j] = AD_Value[j]; // 获取采样值

		if ((float)New_Value[j] - (float)Last_Value[j] > ADError) // 新值与旧值差在抖动内，值不变
			AD_Value[j] = Last_Value[j] / 10;
		AD_Value[j] = New_Value[j] / 10;
		Last_Value[j] = AD_Value[j]; // 每次结束后将旧值给Last_Value数组
	}
}

/**
 * @brief 将需要发送的数据转为8字节为单位的数组中，等待发送
 */
void AD_To_TxPacket(void)
{
	// 这里使用遥控器只有个位有小部分波动，舍去个位
	temp[0] = ((float)AD_Value[0] / 10.0) * K_P;
	temp[1] = ((float)AD_Value[1] / 10.0) * K_R ;
	temp[2] = -((float)AD_Value[2] / 10.0) * K_G + 100;
	// Yaw.float_value/=10;

	if (temp[0] > 60) // Pitch限幅(0~60,对应角度-30~30)
		temp[0] = 60;
	if (temp[0] < 0)
		temp[0] = 0;

	if (temp[1] > 60) // Roll限幅
		temp[1] = 60;
	if (temp[1] < 0)
		temp[1] = 0;

	if (temp[2] > 100.0) // Gas限幅
		temp[2] = 100.0;
	if (temp[2] < 50.0)
		temp[2] = 50.0;

	// 循环移位，超过两个字节数据就乱了，不知道是不是编译器的问题
	// Pitch
	TransmitData_Buff[1] = (uint32_t)temp[0] >> 24;
	TransmitData_Buff[2] = (uint32_t)temp[0] >> 16;
	TransmitData_Buff[3] = (uint32_t)temp[0] >> 8;
	TransmitData_Buff[4] = (uint32_t)temp[0];
	// Roll
	TransmitData_Buff[5] = (uint32_t)temp[1] >> 24;
	TransmitData_Buff[6] = (uint32_t)temp[1] >> 16;
	TransmitData_Buff[7] = (uint32_t)temp[1] >> 8;
	TransmitData_Buff[8] = (uint32_t)temp[1];
	// Gas
	TransmitData_Buff[9] = (uint32_t)temp[2] >> 24;
	TransmitData_Buff[10] = (uint32_t)temp[2] >> 16;
	TransmitData_Buff[11] = (uint32_t)temp[2] >> 8;
	TransmitData_Buff[12] = (uint32_t)temp[2];
}
